<?php 

session_start();
unset($_SESSION["lastname"]);
unset($_SESSION["password"]);
// session_destroy();

header("Location: adminlog.php");

?>
