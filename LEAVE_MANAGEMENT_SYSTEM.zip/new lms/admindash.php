<?php 
session_start();

if (!isset($_SESSION['lastname'])) {
    header("Location: adminlog.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="side.css">
    <title>Welcome</title>

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7f6;
        }

        h1 {
            text-align: center;
            margin: 20px 0;
            font-size: 28px;
            color: #2c3e50;
            font-weight: bold;
        }

        h1 a {
            text-decoration: none;
            color: #2c6e49;
            border-bottom: 3px solid #2c6e49;
            padding-bottom: 5px;
        }

        /* Sidebar */
        .sidebar {
            background: #2c6e49;
            padding-top: 20px;
        }

        .sidebar header {
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 10px;
        }

        .sidebar a {
            display: block;
            padding: 14px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background: #3f8c65;
        }

        /* Table Styling */
        .table-container {
            width: 95%;
            margin: 20px auto;
            background: white;
            border-radius: 8px;
            padding: 15px;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            overflow-x: auto;
        }

        table {
            width: 100%;
            border-collapse: collapse;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            padding: 12px 15px;
            text-align: center;
            border-bottom: 1px solid #ddd;
        }

        th {
            background-color: #2c6e49;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #eefaf3;
            transition: 0.3s;
        }

        /* Search bar */
        .search-box {
            text-align: right;
            margin: 10px 0;
        }

        .search-box input {
            padding: 8px 12px;
            width: 250px;
            border: 1px solid #ccc;
            border-radius: 6px;
            font-size: 14px;
        }

        .search-box input:focus {
            outline: none;
            border-color: #2c6e49;
            box-shadow: 0 0 5px rgba(44,110,73,0.5);
        }
    </style>
</head>
<body>
    <input type="checkbox" id="check">
    <label for="check">
      <i id="btn">☰</i>
      <i id="cancel">☰</i>
    </label>

    <!-- Sidebar -->
    <div class="sidebar" style="margin-top: 40px; height:auto;">
      <header style="text-align: center; height: 11.2vh;">
        <img src="AVATAR.png" alt="Avatar" style="width:20%; border-radius:50%;">
        <h> ADMIN </h>
      </header>

      <a href="admindash.php"><span>MY EMPLOYEE</span></a>
      <a href="veiw applicants.php"><span>VIEW APPLICATION</span></a>
      <a href="editemplo.php"><span>EDIT EMPLOYEE</span></a>
      <a href="admin_viewleave.php"><span>VIEW LEAVE BALANCES</span></a>
      <a href="adminlogout.php"><span>LOG OUT</span></a>
    </div>
     
    <h1><a href="#">Employee Leave Management System</a></h1>

    <div class="table-container">
        <!-- 🔍 Employee Search -->
        <div class="search-box">
            <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search for employees...">
        </div>

        <table id="employeeTable">
          <thead>
            <tr>
              <th>FNAME</th>
              <th>MNAME</th>
              <th>LNAME</th>
              <th>EMAIL</th>
              <th>PHONE</th>
              <th>BIRTHDATE</th>
              <th>DEPARTMENT</th>
              <th>ADDRESS</th>
              <th>GENDER</th>
            </tr>
          </thead>
          <tbody>
            <?php
            $conn = mysqli_connect("localhost", "root", "", "nlms");
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            $sql = "SELECT firstname,middlename,lastname,email,phone,birthdate,department,address,gender FROM employee";
            $result = $conn->query($sql);

            if ($result->num_rows > 0) {
                while($row = $result->fetch_assoc()) {
                    echo "<tr>
                        <td>" . $row["firstname"] . "</td>
                        <td>" . $row["middlename"] . "</td>
                        <td>" . $row["lastname"] . "</td>
                        <td>" . $row["email"] . "</td>
                        <td>" . $row["phone"] . "</td>
                        <td>" . $row["birthdate"] . "</td>
                        <td>" . $row["department"] . "</td>
                        <td>" . $row["address"] . "</td>
                        <td>" . $row["gender"] . "</td>
                    </tr>";
                }
            } else { 
                echo "<tr><td colspan='9'>0 results</td></tr>"; 
            }
            $conn->close();
            ?>
          </tbody>
        </table>
    </div>

    <?php include 'footer.php'; ?>

    <!-- 🔍 Search Script -->
    <script>
      function searchTable() {
        let input = document.getElementById("searchInput").value.toLowerCase();
        let rows = document.querySelectorAll("#employeeTable tbody tr");

        rows.forEach(row => {
          let text = row.textContent.toLowerCase();
          row.style.display = text.includes(input) ? "" : "none";
        });
      }
    </script>
</body>
</html>