<?php 
session_start();

if (!isset($_SESSION['lastname'])) {
    header("Location: adminlog.php");
    exit();
}

$conn = mysqli_connect("localhost", "root", "", "nlms");
if (!$conn) { die("Connection failed: " . mysqli_connect_error()); }
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>Admin - Leave Balances</title>
<link rel="stylesheet" href="side.css">
<style>
    body { font-family: Arial, sans-serif; background: #f9f9f9; margin: 0; }
    h2 { text-align: center; margin: 20px 0; color: #333; }

    table { 
        width: 95%;
        margin: 20px auto;
        border-collapse: collapse;
        background: #fff;
        box-shadow: 0 2px 6px rgba(0,0,0,0.1);
    }
    th, td { padding: 12px; border: 1px solid #ddd; text-align: center; }
    th { background-color: #4a7466; color: #fff; }
    tr:nth-child(even) { background-color: #f2f2f2; }
</style>
</head>
<body>

<!-- Sidebar -->
<input type="checkbox" id="check">
<label for="check">
  <i id="btn">☰</i>
  <i id="cancel">☰</i>
</label>

<div class="sidebar" style="margin-top: 40px; height:auto;">
  <header style="text-align: center; height: 11.2vh;">
      <img src="AVATAR.png" alt="Avatar" style="width:20%;">
      <h> ADMIN </h>
  </header>

  <a href="admindash.php">MY EMPLOYEE</a>
  <a href="veiw applicants.php">VIEW APPLICATION</a>
  <a href="editemplo.php">EDIT EMPLOYEE</a>
  <a href="admin_viewleave.php">VIEW LEAVE BALANCES</a>
  <a href="adminlogout.php">LOG OUT</a>
</div>

<h2>Employee Leave Balances</h2>

<table>
    <tr>
        <th>Employee Name</th>
        <th>Email</th>
        <th>Leave Type</th>
        <th>Category</th>
        <th>Start Date</th>
        <th>End Date</th>
        <th>Approval</th>
        <th>Days Remaining</th>
    </tr>

    <?php
    $today = date("Y-m-d");

    $sql = "SELECT lastname, email, leavetype, leavecatergory, startdate, enddate, approval 
            FROM leaveform ORDER BY lastname";
    $result = $conn->query($sql);

    if ($result->num_rows > 0) {
        while ($leave = $result->fetch_assoc()) {
            $end = $leave['enddate'];
            $remaining = (strtotime($end) - strtotime($today)) / (60*60*24);
            if ($remaining < 0) $remaining = 0;

            echo "<tr>
                  <td>{$leave['lastname']}</td>
                  <td>{$leave['email']}</td>
                  <td>{$leave['leavetype']}</td>
                  <td>{$leave['leavecatergory']}</td>
                  <td>{$leave['startdate']}</td>
                  <td>{$leave['enddate']}</td>
                  <td>{$leave['approval']}</td>
                  <td>{$remaining} day(s)</td>
                  </tr>";
        }
    } else {
        echo "<tr><td colspan='8'>No leave records found.</td></tr>";
    }

    $conn->close();
    ?>
</table>

<?php include 'footer.php'; ?>
</body>
</html>
