-- --------------------------------------------------------
-- Database: `nlms_system`
-- --------------------------------------------------------

CREATE DATABASE IF NOT EXISTS `nlms`;
USE `nlms`;

-- --------------------------------------------------------
-- Table structure for table `admins`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `admins` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data for `admins`
INSERT INTO `admins` (`firstname`,`middlename`,`lastname`, `email`,`phone`,`birthdate`,`department`,`address`,`gender`,`password`) VALUES
('Samwel','Samwel','Tagata', 'samwel890@gmail.com','0626401069','01/01/2003','Finance','Isamilo','male' ,'112233');

-- --------------------------------------------------------
-- Table structure for table `Employee`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `Employee` (
  `id` int(10) NOT NULL AUTO_INCREMENT,
  `firstname` varchar(255) NOT NULL,
  `middlename` varchar(255) NOT NULL,
  `lastname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(255) NOT NULL,
  `birthdate` varchar(255) NOT NULL,
  `department` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `gender` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Sample data for `Employee`
INSERT INTO `Employee` (`firstname`,`middlename`,`lastname`, `email`,`phone`,`birthdate`,`department`,`address`,`gender`,`password`) VALUES
('gerald','dionidas','ndyamukama', 'gerald@gmail.com','0789555656','18/05/2021','tehama','mbagala25slp','male' ,'0139a3c5cf42394be982e766c93f5ed0');

-- --------------------------------------------------------
-- Table structure for table `leaveform`
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leaveform` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `lastname` varchar(20) NOT NULL,
  `email` varchar(20) NOT NULL,
  `leavetype` varchar(20) NOT NULL,
  `leavecatergory` varchar(20) NOT NULL,
  `startdate` date NOT NULL,
  `enddate` date NOT NULL,
  `fromwhere` varchar(20) NOT NULL,
  `towhere` varchar(20) NOT NULL,
  `description` varchar(191) NOT NULL,
  `file` blob NOT NULL,
  `approval` varchar(191) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;h

-- Sample data for `leaveform`
INSERT INTO `leaveform` (`id`,`lastname`,`email`, `leavetype`, `leavecatergory`, `startdate`, `enddate`, `fromwhere`, `towhere`, `description`, `file`, `approval`) VALUES
(22,'jomba nyuso kichaa','jomba@gmail.com' ,'paid', 'Mandatory Leave', '2022-09-05', '2022-09-26', 'Dodoma', 'Morogoro', 'THANKS GOD', 0x77616c6c7061706572666c6172652e636f6d5f77616c6c7061706572202832292e6a7067,'WAITING FOR APPROVAL');

-- --------------------------------------------------------
-- Table structure for table `leaves` (leave balance table)
-- --------------------------------------------------------
CREATE TABLE IF NOT EXISTS `leaves` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,
    `lastname` VARCHAR(255) NOT NULL,
    `start_date` DATE NOT NULL,
    `end_date` DATE NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- Optional sample data for `leaves`
INSERT INTO `leaves` (`id`, `lastname`, `start_date`, `end_date`) VALUES
(1, 'gerald', '2025-08-20', '2025-08-25');
