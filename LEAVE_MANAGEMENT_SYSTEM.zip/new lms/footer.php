<!-- footer.php -->
<footer style="background-color:#588c7e; color:white; text-align:center; padding:15px; position:fixed; bottom:0; width:100%;">
    &copy; <?php echo date("Y"); ?><h3> Employee Leave Management System. All rights reserved.
</h3></footer>
