<?php 
session_start();

if (!isset($_SESSION['lastname'])) {
    header("Location: adminlog.php");
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit Employee</title>
    <link rel="stylesheet" href="side.css">

    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            padding: 0;
            background: #f4f7f6;
        }

        h1 {
            text-align: center;
            margin: 20px 0;
            font-size: 28px;
            color: #444;
            font-weight: bold;
        }

        h1 a {
            text-decoration: none;
            color: #2c6e49;
            border-bottom: 3px solid #2c6e49;
            padding-bottom: 5px;
        }

        /* Sidebar override */
        .sidebar {
            background: #2c6e49;
            padding-top: 20px;
        }

        .sidebar header {
            color: white;
            font-size: 18px;
            font-weight: bold;
            padding: 10px;
        }

        .sidebar a {
            display: block;
            padding: 14px 20px;
            color: white;
            text-decoration: none;
            transition: background 0.3s;
        }

        .sidebar a:hover {
            background: #3f8c65;
        }

        /* Table Styling */
        table { 
            margin: 40px auto;
            box-shadow: 0 4px 12px rgba(0,0,0,0.1);
            border-collapse: collapse;
            width: 95%;
            background: white;
            border-radius: 8px;
            overflow: hidden;
        }

        th, td {
            border: 1px solid #ddd;
            padding: 12px 15px;
            text-align: center;
        }

        th {
            background-color: #2c6e49;
            color: white;
            font-weight: bold;
            text-transform: uppercase;
        }

        tr:nth-child(even) {
            background-color: #f9f9f9;
        }

        tr:hover {
            background-color: #eefaf3;
            transition: 0.3s;
        }

        /* Buttons */
        .btn {
            padding: 6px 12px;
            font-size: 13px;
            border-radius: 4px;
            text-decoration: none;
            font-weight: bold;
            display: inline-block;
        }

        .btn-update {
            background: #3498db;
            color: white;
        }

        .btn-update:hover {
            background: #217dbb;
        }

        .btn-delete {
            background: #e74c3c;
            color: white;
        }

        .btn-delete:hover {
            background: #c0392b;
        }

        /* Responsive Table */
        .table-container {
            width: 100%;
            overflow-x: auto;
        }
    </style>
</head>
<body>
    <input type="checkbox" id="check">
    <label for="check">
        <i id="btn">☰</i>
        <i id="cancel">☰</i>
    </label>
    <div class="sidebar" style="margin-top: 40px; height:auto;">
        <header>
            <img src="AVATAR.png" alt="Avatar" style="width:40px; border-radius:50%;"><br>
            ADMIN
        </header>
        <a href="admindash.php"><span>MY EMPLOYEE</span></a>
        <a href="veiw applicants.php"><span>VIEW APPLICATION</span></a>
        <a href="editemplo.php"><span>EDIT EMPLOYEE</span></a>
        <a href="adminlogout.php"><span>LOG OUT</span></a>
    </div><br>

    <h1><a href="#">Employee Leave Management System</a></h1>

    <div class="table-container">
        <?php include 'config.php'; ?>

        <table class="table">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>FNAME</th>
                    <th>MNAME</th>
                    <th>LNAME</th>
                    <th>EMAIL</th>
                    <th>PHONE</th>
                    <th>BIRTHDATE</th>
                    <th>DEPARTMENT</th>
                    <th>ADDRESS</th>
                    <th>GENDER</th>
                    <th>ACTIONS</th>
                </tr>
            </thead>
            <tbody>
                <?php
                $sql="SELECT * FROM `employee`";
                $result=mysqli_query($conn,$sql);
                if($result){
                    while($row=mysqli_fetch_assoc($result)){
                        $id=$row['id'];
                        $fname=$row['firstname'];
                        $mname=$row['middlename'];
                        $lname=$row['lastname'];
                        $email=$row['email'];
                        $phone=$row['phone'];
                        $birthdate=$row['birthdate'];
                        $department=$row['department'];
                        $address=$row['address'];
                        $gender=$row['gender'];
                        
                        echo '<tr>
                            <td>'.$id.'</td>
                            <td>'.$fname.'</td>
                            <td>'.$mname.'</td>
                            <td>'.$lname.'</td>
                            <td>'.$email.'</td>
                            <td>'.$phone.'</td>
                            <td>'.$birthdate.'</td>
                            <td>'.$department.'</td>
                            <td>'.$address.'</td>
                            <td>'.$gender.'</td>
                            <td>
                                <a class="btn btn-update" href="updateep.php?updateid='.$id.'">Update</a>
                                <a class="btn btn-delete" href="deleteep.php?deleteid='.$id.'">Delete</a>
                            </td>
                        </tr>';
                    }
                }
                ?>
            </tbody>
        </table>
    </div>
    <?php include 'footer.php'; ?>
</body>
</html>