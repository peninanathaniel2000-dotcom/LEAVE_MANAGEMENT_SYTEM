<?php 

include 'config.php';

session_start();

error_reporting(0);

if (isset($_SESSION['lastname'])) {
    header("Location: admindash.php");
}

if (isset($_POST['submit'])) {
	$email = $_POST['email'];
	$password = md5($_POST['password']);

	$sql = "SELECT * FROM admins WHERE email='$email' AND password='$password'";
	$result = mysqli_query($conn, $sql);
	if ($result->num_rows > 0) {
		$row = mysqli_fetch_assoc($result);
		$_SESSION['lastname'] = $row['lastname'];
		header("Location: admindash.php");
	} else {
		echo "<script>alert('Woops! Email or Password is Wrong.')</script>";
	}
}

?>

<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">

	<link rel="stylesheet" href="lore.css">
	<style>
		.container{
		background-image:url("avida890.jnpg.avif");
		 background-size: contain;
/* ✅ Prevent repeating */
  background-size: cover;       /* ✅ Make it cover the whole screen */
  background-position: center;  /* ✅ Center the image */
  background-attachment: fixed; /* (optional) keep it fixed when scrolling */
}
		
		</style>

	<title>Login Form </title>
</head>
<body>
	<div class="container">
		<form action="" method="POST" class="login-email">
			<p class="login-text" style="font-size: 2rem; font-weight: 800;">Admin Login</p>
			<div class="input-group">
				<input type="email" placeholder="Email" name="email" value="<?php echo $email; ?>" required>
			</div>
			<div class="input-group">
				<input type="password" placeholder="Password" name="password" value="<?php echo $_POST['password']; ?>" required>
			</div>
			<div class="input-group">
				<button name="submit" class="btn">Login</button>
			</div>
			<p class="login-register-text">Don't have an account? <a href="adminreg.php">Register Here</a>.</p>
		</form>
	</div>
	<?php include 'footer.php'; ?>
</body>
</html>