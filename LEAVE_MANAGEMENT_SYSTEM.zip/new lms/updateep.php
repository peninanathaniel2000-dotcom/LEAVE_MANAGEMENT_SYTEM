<?php 
include 'config.php';
session_start();

$id = $_GET['updateid'] ?? null;
if (!$id) {
    die("No employee ID provided!");
}

// Fetch employee details
$sql = "SELECT * FROM employee WHERE id=$id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);

if (!$row) {
    die("Employee not found!");
}

$phone = $row['phone'];
$department = $row['department'];

// Handle Update Details
if (isset($_POST['update'])) {
    $phone      = $_POST['phone'];
    $department = $_POST['department'];

    $sql = "UPDATE employee SET phone='$phone', department='$department' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('employee details updated successfully 🤩'); window.location='editemplo.php';</script>";
        exit;
    } else {
        die("Error updating details: " . mysqli_error($conn));
    }
}

// Handle Reset Password
if (isset($_POST['reset'])) {
    $defaultPass = md5("12345678"); // MD5 hash for login compatibility

    $sql = "UPDATE employee SET password='$defaultPass' WHERE id=$id";
    if (mysqli_query($conn, $sql)) {
        echo "<script>alert('Password reset to 12345678 🤩'); window.location='editemplo.php';</script>";
        exit;
    } else {
        die("Error resetting password: " . mysqli_error($conn));
    }
}
?>
<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="tarifa.css"/>
    <title>Update Employee</title>
</head>
<body>
<h4 align="center"><a href="">Employee Leave Management System </a></h4>
<div class="container"><center>
    <div class="container">
        <form action="" method="POST">
            <h2 style="padding-bottom:10px;">UPDATE EMPLOYEE</h2>

            <div>Phone:
                <input type="text" name="phone" value="<?php echo htmlspecialchars($phone); ?>">
            </div>
            <div>Department:
                <input type="text" name="department" value="<?php echo htmlspecialchars($department); ?>">
            </div>
            <br>
            <div>
                <!-- Update Button -->
                <button type="submit" name="update" style="background-color: #3498db; color:white; padding:6px 15px; border:none; border-radius:5px; margin-right:10px;">
                    Update Details
                </button>

                <!-- Reset Password Button -->
                <button type="submit" name="reset" style="background-color: #e67e22; color:white; padding:6px 15px; border:none; border-radius:5px;">
                    Reset Password
                </button>
            </div>
        </form>
    </div>
</center></div>
<?php include 'footer.php'; ?>
</body>
</html>
