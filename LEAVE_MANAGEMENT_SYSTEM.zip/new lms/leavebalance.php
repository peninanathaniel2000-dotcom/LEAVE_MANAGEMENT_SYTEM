<?php
session_start();
if (!isset($_SESSION['lastname'])) {
    header("Location: index.php");
    exit();
}

// Database connection
$conn = new mysqli("localhost", "root", "", "nlms");
if ($conn->connect_error) {
    die("Connection failed: " . htmlspecialchars($conn->connect_error));
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Leave Balance</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <style>
        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin: 0;
            background-color: #f5f5f5;
        }
        /* Sidebar */
        .sidebar {
            position: fixed;
            top: 0;
            left: 0;
            width: 220px;
            height: 100%;
            background-color: #7fb3a3;
            padding-top: 20px;
            color: white;
        }
        .sidebar header {
            text-align: center;
            margin-bottom: 20px;
        }
        .sidebar img {
            width: 60px;
            border-radius: 50%;
        }
        .sidebar h3 {
            display: block;
            margin-top: 10px;
            font-size: 18px;
            font-weight: bold;
        }
        .sidebar a {
            display: block;
            padding: 12px 20px;
            color: white;
            text-decoration: none;
            font-size: 16px;
        }
        .sidebar a:hover {
            background-color: rgba(255,255,255,0.1);
        }
        /* Main Content */
        .main-content {
            margin-left: 240px;
            padding: 20px;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        /* Table Styling */
        table {
            width: 100%;
            border-collapse: collapse;
            margin-top: 20px;
            background-color: white;
            box-shadow: 0 0 10px rgba(0,0,0,0.05);
        }
        th, td {
            padding: 12px 15px;
            border: 1px solid #ddd;
            text-align: center;
        }
        th {
            background-color: #4a7466;
            color: white;
        }
        tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        /* Return Button Container */
        .return-button-container {
            display: flex;
            justify-content: center;
            margin: 20px 0;
        }
        /* Return Button */
        .return-button {
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            font-size: 14px;
            transition: all 0.3s ease;
        }
        .return-button:hover {
            background: linear-gradient(135deg, #5a9288 0%, #7fb3a3 100%);
        }
    </style>
</head>
<body>
    <!-- Sidebar -->
    <div class="sidebar">
        <header>
            <img src="AVATAR.png" alt="Avatar">
            <h3><?php echo htmlspecialchars($_SESSION['lastname']); ?></h3>
        </header>
        <a href="my.php">MY BOARD</a>
        <a href="leaveform.php">APPLY LEAVE</a>
        <a href="leavebalance.php">LEAVE BALANCE</a>
        <a href="feedback.php">FEEDBACK</a>
        <a href="passchange.php">MANAGE PASSWORD</a>
        <a href="logout.php">LOG OUT</a>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <h2>Leave Balance</h2>
        <table>
            <tr>
                <th>Leave Type</th>
                <th>Start Date</th>
                <th>End Date</th>
                <th>From</th>
                <th>To</th>
                <th>Description</th>
                <th>Approval</th>
                <th>Days Remaining</th>
            </tr>
            <?php
            // Prepare SQL query to prevent SQL injection
            $stmt = $conn->prepare("SELECT leavetype, startdate, enddate, fromwhere, towhere, description, approval FROM leaveform WHERE lastname = ?");
            $stmt->bind_param("s", $_SESSION['lastname']);
            $stmt->execute();
            $result_leave = $stmt->get_result();

            if ($result_leave->num_rows > 0) {
                while ($leave = $result_leave->fetch_assoc()) {
                    $today = date("Y-m-d");
                    $end = $leave['enddate'];
                    $remaining = (strtotime($end) - strtotime($today)) / (60*60*24);
                    if ($remaining < 0) $remaining = 0;

                    echo "<tr>
                        <td>" . htmlspecialchars($leave['leavetype']) . "</td>
                        <td>" . htmlspecialchars($leave['startdate']) . "</td>
                        <td>" . htmlspecialchars($leave['enddate']) . "</td>
                        <td>" . htmlspecialchars($leave['fromwhere']) . "</td>
                        <td>" . htmlspecialchars($leave['towhere']) . "</td>
                        <td>" . htmlspecialchars($leave['description']) . "</td>
                        <td>" . htmlspecialchars($leave['approval']) . "</td>
                        <td>" . htmlspecialchars($remaining) . " day(s)</td>
                    </tr>";
                }
            } else {
                echo "<tr><td colspan='8'>No leave records found.</td></tr>";
            }
            $stmt->close();
            $conn->close();
            ?>
        </table>
        <div class="return-button-container">
            <a href="my.php" class="return-button">Return to Dashboard</a>
        </div>
    </div>
</body>
</html>