<?php 
session_start();
if (!isset($_SESSION['lastname'])) { 
    header("Location: leaveform.php"); 
    exit(); 
} 
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Employee Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            display: flex;
            min-height: 100vh;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 15px;
        }

        .sidebar-header h3 {
            font-size: 18px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px 25px;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            font-weight: 400;
            font-size: 14px;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            border-left: 3px solid white;
            padding-left: 30px;
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.15);
            border-left: 3px solid white;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            flex: 1;
            padding: 0;
        }

        .content-header {
            background-color: white;
            padding: 25px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .content-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 300;
        }

        .content-header p {
            color: #666;
            margin-top: 5px;
            font-size: 14px;
        }

        .container {
            padding: 0 30px;
        }

        /* Table Styles */
        table {
            width: 100%;
            background-color: white;
            border-radius: 8px;
            overflow: hidden;
            box-shadow: 0 4px 6px rgba(0,0,0,0.1);
            margin-bottom: 40px;
            border-collapse: collapse;
        }

        th {
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            padding: 15px 12px;
            text-align: left;
            font-weight: 500;
            font-size: 13px;
            text-transform: uppercase;
            letter-spacing: 0.5px;
        }

        td {
            padding: 12px;
            border-bottom: 1px solid #eee;
            color: #333;
            font-size: 14px;
        }

        tr:hover {
            background-color: #f8f9fa;
        }

        tr:last-child td {
            border-bottom: none;
        }

        /* Mobile Toggle Button */
        .mobile-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            background: #7fb3a3;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1001;
            font-size: 18px;
        }

        /* Return Button */
        .return-button {
            display: block;
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            text-decoration: none;
            padding: 10px 20px;
            border-radius: 5px;
            margin: 20px 30px;
            width: fit-content;
            float: right;
            font-size: 14px;
            transition: all 0.3s ease;
        }

        .return-button:hover {
            background: linear-gradient(135deg, #5a9288 0%, #7fb3a3 100%);
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }

            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            .content-header {
                padding-left: 70px;
            }

            .return-button {
                margin: 20px;
            }
        }

        /* Footer */
        .footer {
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            text-align: center;
            padding: 20px;
            margin-top: auto;
            font-size: 14px;
        }
    </style>
</head>
<body>
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" onclick="toggleSidebar()">☰</button>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="AVATAR.png" alt="Avatar">
            <h3><?php echo htmlspecialchars($_SESSION['lastname']); ?></h3>
        </div>
        <div class="sidebar-menu">
            <a href="my.php" class="active">My Board</a>
            <a href="leaveform.php">Apply Leave</a>
            <a href="feedback.php">Feedback</a>
            <a href="passchange.php">Manage Password</a>
            <a href="logout.php">Log Out</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1>Employee Dashboard</h1>
            <p>View and manage your leave applications</p>
        </div>

        <div class="container">
            <table>
                <thead>
                    <tr>
                        <th>Last Name</th>
                        <th>Email</th>
                        <th>Leave Type</th>
                        <th>Category</th>
                        <th>Start Date</th>
                        <th>End Date</th>
                        <th>From</th>
                        <th>To</th>
                        <th>Description</th>
                        <th>Attachment</th>
                        <th>Status</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $conn = mysqli_connect("localhost", "root", "", "nlms");

                    if ($conn->connect_error) {
                        die("Connection failed: " . $conn->connect_error);
                    }

                    $sql = "SELECT lastname, email, leavetype, leavecatergory, startdate, enddate, fromwhere, towhere, description, file, approval 
                            FROM leaveform 
                            WHERE lastname = '".mysqli_real_escape_string($conn, $_SESSION['lastname'])."'";

                    $result = $conn->query($sql);

                    if ($result->num_rows > 0) {
                        while($row = $result->fetch_assoc()) {
                            // Build file path if exists
                            $attachment = "";
                            if (!empty($row["file"])) {
                                $filePath = "Uploads/" . $row["file"];
                                $ext = strtolower(pathinfo($filePath, PATHINFO_EXTENSION));

                                // Preview images inline, otherwise make a download link
                                if (in_array($ext, ["jpg", "jpeg", "png", "gif", "webp"])) {
                                    $attachment = "<img src='$filePath' alt='Attachment' style='width:40px;height:40px;object-fit:cover;border-radius:4px;'><br>
                                                   <a href='$filePath' target='_blank' style='font-size:12px;color:#7fb3a3;'>View</a>";
                                } else {
                                    $attachment = "<a href='$filePath' target='_blank' style='color:#7fb3a3;'>Download</a>";
                                }
                            } else {
                                $attachment = "<span style='color:#999;font-style:italic;'>No file</span>";
                            }

                            echo "<tr>
                                    <td>".htmlspecialchars($row["lastname"])."</td>
                                    <td>".htmlspecialchars($row["email"])."</td>
                                    <td>".htmlspecialchars($row["leavetype"])."</td>
                                    <td>".htmlspecialchars($row["leavecatergory"])."</td>
                                    <td>".htmlspecialchars($row["startdate"])."</td>
                                    <td>".htmlspecialchars($row["enddate"])."</td>
                                    <td>".htmlspecialchars($row["fromwhere"])."</td>
                                    <td>".htmlspecialchars($row["towhere"])."</td>
                                    <td>".htmlspecialchars($row["description"])."</td>
                                    <td>$attachment</td>
                                    <td>".htmlspecialchars($row["approval"])."</td>
                                  </tr>";
                        }
                    } else { 
                        echo "<tr><td colspan='11' style='text-align:center;color:#999;font-style:italic;'>No employee record found.</td></tr>";
                    }

                    $conn->close();
                    ?>
                </tbody>
            </table>
        </div>

        <a href="my.php" class="return-button">Return to Dashboard</a>

        <div class="footer">
            © 2025 Employee Leave Management System. All rights reserved.
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.querySelector('.mobile-toggle');
            
            if (window.innerWidth <= 768 && !sidebar.contains(event.target) && !toggle.contains(event.target)) {
                sidebar.classList.remove('active');
            }
        });
    </script>
</body>
</html>