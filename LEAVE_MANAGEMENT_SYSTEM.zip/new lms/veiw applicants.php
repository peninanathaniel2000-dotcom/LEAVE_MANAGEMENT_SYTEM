<?php 
session_start();

if (!isset($_SESSION['lastname'])) {
 header("Location: leaveform.php");
 exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" href="side.css">
  <title>View Applicants</title>
  <style>
    body {font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;background:#f4f7f6;margin:0;}
    h4{text-align:center;margin:20px 0;font-size:24px;color:#2c3e50;font-weight:bold;}
    h4 a{text-decoration:none;color:#2c6e49;border-bottom:3px solid #2c6e49;padding-bottom:4px;}
    .table-container{width:95%;margin:20px auto;background:white;border-radius:8px;padding:15px;box-shadow:0 4px 12px rgba(0,0,0,0.1);overflow-x:auto;}
    table{width:100%;border-collapse:collapse;}
    th,td{padding:12px 15px;text-align:center;border-bottom:1px solid #ddd;font-size:14px;}
    th{background:#2c6e49;color:white;text-transform:uppercase;font-size:13px;}
    tr:nth-child(even){background:#f9f9f9;}
    tr:hover{background:#eefaf3;transition:0.3s;}
    .btn-response{padding:6px 12px;background:#3498db;color:white;text-decoration:none;border-radius:4px;font-size:13px;font-weight:bold;}
    .btn-response:hover{background:#217dbb;}
    .search-box{text-align:right;margin-bottom:10px;}
    .search-box input{padding:8px 12px;width:250px;border:1px solid #ccc;border-radius:6px;font-size:14px;}
    .search-box input:focus{outline:none;border-color:#2c6e49;box-shadow:0 0 5px rgba(44,110,73,0.5);}
  </style>
</head>
<body>
  <input type="checkbox" id="check">
  <label for="check"><i id="btn">☰</i><i id="cancel">☰</i></label>

  <!-- Sidebar -->
  <div class="sidebar" style="margin-top:40px; height:auto;">
    <header style="text-align:center; height:11.2vh;">
      <img src="AVATAR.png" alt="Avatar" style="width:20%;border-radius:50%;">
      <h> ADMIN </h> 
    </header>
    <a href="admindash.php"><span>MY EMPLOYEE</span></a>
    <a href="veiw applicants.php"><span>VIEW APPLICATION</span></a>
    <a href="editemplo.php"><span>EDIT EMPLOYEE</span></a>
    <a href="adminlogout.php"><span>LOG OUT</span></a>
  </div><br>
   
  <h4><a href="#">Employee Leave Management System</a></h4>

  <div class="table-container">
    <div class="search-box">
      <input type="text" id="searchInput" onkeyup="searchTable()" placeholder="Search leave applications...">
    </div>

    <table id="leaveTable">
      <thead>
        <tr>
          <th>LASTNAME</th>
          <th>EMAIL</th>
          <th>LEAVE TYPE</th>
          <th>LEAVE CATEGORY</th>
          <th>STARTDATE</th>
          <th>ENDDATE</th>
          <th>FROM</th>
          <th>TO</th>
          <th>DESCRIPTION</th>
          <th>ATTACHMENT</th>
          <th>RESPONSE</th>
          <th>ACTION</th>
        </tr>
      </thead>
      <tbody>
        <?php
        $conn = mysqli_connect("localhost", "root", "", "nlms");
        if ($conn->connect_error) {
          die("Connection failed: " . $conn->connect_error);
        }
        $sql = "SELECT lastname,email, leavetype, leavecatergory, startdate , enddate, fromwhere, towhere, description, file, approval FROM leaveform";
        $result = $conn->query($sql);
        if ($result->num_rows > 0) {
          while($row = $result->fetch_assoc()) {
            echo "<tr>
              <td>".$row['lastname']."</td>
              <td>".$row['email']."</td>
              <td>".$row['leavetype']."</td>
              <td>".$row['leavecatergory']."</td>
              <td>".$row['startdate']."</td>
              <td>".$row['enddate']."</td>
              <td>".$row['fromwhere']."</td>
              <td>".$row['towhere']."</td>
              <td>".$row['description']."</td>
              <td>";
                if (!empty($row['file'])) {
                    $file = "uploads/".$row['file'];
                    $ext = strtolower(pathinfo($file, PATHINFO_EXTENSION));
                    if (in_array($ext, ['jpg','jpeg','png'])) {
                        echo "<a href='$file' target='_blank'><img src='$file' width='60' height='60' style='object-fit:cover;border:1px solid #ccc;'></a>";
                    } elseif ($ext == 'pdf') {
                        echo "<a href='$file' target='_blank'>📄 View PDF</a>";
                    } elseif (in_array($ext, ['doc','docx'])) {
                        echo "<a href='$file' target='_blank'>📘 View Document</a>";
                    } elseif (in_array($ext, ['ppt','pptx'])) {
                        echo "<a href='$file' target='_blank'>📊 View Presentation</a>";
                    } else {
                        echo "<a href='$file' download>⬇ Download</a>";
                    }
                } else {
                    echo "No File";
                }
            echo "</td>
              <td>".$row['approval']."</td>
              <td><a class='btn-response' href='updateapplicant.php?id=".$row['email']."'>RESPONSE</a></td>
            </tr>";
          }
        } else {
          echo "<tr><td colspan='12'>0 results</td></tr>";
        }
        $conn->close();
        ?>
      </tbody>
    </table>
  </div>

  <script>
    function searchTable() {
      let input = document.getElementById("searchInput").value.toLowerCase();
      let rows = document.querySelectorAll("#leaveTable tbody tr");
      rows.forEach(row => {
        row.style.display = row.textContent.toLowerCase().includes(input) ? "" : "none";
      });
    }
  </script>
  <?php include 'footer.php'; ?>
</body>
</html>