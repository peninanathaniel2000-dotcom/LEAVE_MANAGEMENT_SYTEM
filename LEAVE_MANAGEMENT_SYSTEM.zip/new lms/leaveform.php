<?php 
session_start();
if (!isset($_SESSION['lastname'])) {
    header("Location: login.php"); 
    exit();
}

$successMessage = "";

// Submission handler
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $conn = new mysqli("localhost", "root", "", "nlms");
    if ($conn->connect_error) {
        die("Connection failed: " . $conn->connect_error);
    }

    // File upload
    $uploadDir = "uploads/";
    if (!is_dir($uploadDir)) mkdir($uploadDir, 0777, true);

    $fileName = $_FILES['file']['name'] ?? '';
    $fileTmp  = $_FILES['file']['tmp_name'] ?? '';
    $fileExt  = strtolower(pathinfo($fileName, PATHINFO_EXTENSION));
    $allowed  = ['jpg','jpeg','png','pdf','doc','docx','ppt','pptx'];
    $uploadedFile = "";

    if (!empty($fileName) && in_array($fileExt, $allowed)) {
        $newName = uniqid().".".$fileExt;
        $targetFile = $uploadDir.$newName;
        if (move_uploaded_file($fileTmp, $targetFile)) {
            $uploadedFile = $newName;
        }
    }

    // Insert into DB
    $stmt = $conn->prepare("INSERT INTO leaveform (lastname,email,leavetype,leavecatergory,startdate,enddate,fromwhere,towhere,description,file,approval) VALUES (?,?,?,?,?,?,?,?,?,?,?)");
    $approval = "WAITING FOR APPROVAL";
    $stmt->bind_param("sssssssssss", $_POST['lastname'], $_POST['email'], $_POST['leavetype'], $_POST['leavecatergory'], $_POST['startdate'], $_POST['enddate'], $_POST['fromwhere'], $_POST['towhere'], $_POST['description'], $uploadedFile, $approval);
    
    if ($stmt->execute()) {
        $successMessage = "Your leave application has been submitted successfully and is now pending approval. You will be notified once it's reviewed.";
    } else {
        $successMessage = "There was an error submitting your application. Please try again.";
    }
    
    $stmt->close();
    $conn->close();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Apply Leave - Employee Dashboard</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            box-sizing: border-box;
        }

        body {
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            background-color: #f5f5f5;
            margin: 0;
            padding: 0;
        }

        /* Sidebar Styles */
        .sidebar {
            width: 250px;
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            position: fixed;
            height: 100vh;
            left: 0;
            top: 0;
            overflow-y: auto;
            transition: transform 0.3s ease;
            z-index: 1000;
        }

        .sidebar-header {
            padding: 30px 20px;
            text-align: center;
            border-bottom: 1px solid rgba(255, 255, 255, 0.1);
        }

        .sidebar-header img {
            width: 80px;
            height: 80px;
            border-radius: 50%;
            object-fit: cover;
            border: 3px solid rgba(255, 255, 255, 0.2);
            margin-bottom: 15px;
        }

        .sidebar-header h3 {
            font-size: 18px;
            font-weight: 500;
            text-transform: uppercase;
            letter-spacing: 1px;
        }

        .sidebar-menu {
            padding: 20px 0;
        }

        .sidebar-menu a {
            display: block;
            color: white;
            text-decoration: none;
            padding: 15px 25px;
            transition: all 0.3s ease;
            border-left: 3px solid transparent;
            font-weight: 400;
            font-size: 14px;
        }

        .sidebar-menu a:hover {
            background-color: rgba(255, 255, 255, 0.1);
            border-left: 3px solid white;
            padding-left: 30px;
        }

        .sidebar-menu a.active {
            background-color: rgba(255, 255, 255, 0.15);
            border-left: 3px solid white;
        }

        /* Main Content */
        .main-content {
            margin-left: 250px;
            min-height: 100vh;
            display: flex;
            flex-direction: column;
        }

        .content-header {
            background-color: white;
            padding: 25px 30px;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .content-header h1 {
            color: #333;
            font-size: 28px;
            font-weight: 300;
        }

        .content-header p {
            color: #666;
            margin-top: 5px;
            font-size: 14px;
        }

        .container {
            padding: 0 30px;
            flex: 1;
            display: flex;
            justify-content: center;
            align-items: flex-start;
        }

        /* Form Styles */
        .form-container {
            background: white;
            padding: 40px;
            max-width: 600px;
            width: 100%;
            border-radius: 12px;
            box-shadow: 0 8px 25px rgba(0,0,0,0.1);
            margin-bottom: 30px;
        }

        .form-title {
            text-align: center;
            margin-bottom: 30px;
            color: #333;
            font-size: 24px;
            font-weight: 300;
        }

        .form-group {
            margin-bottom: 20px;
        }

        .form-group label {
            display: block;
            margin-bottom: 8px;
            color: #555;
            font-weight: 500;
            font-size: 14px;
        }

        .form-group input,
        .form-group select,
        .form-group textarea {
            width: 100%;
            padding: 12px 16px;
            border: 2px solid #e1e5e9;
            border-radius: 8px;
            font-size: 14px;
            transition: border-color 0.3s ease;
            font-family: inherit;
        }

        .form-group input:focus,
        .form-group select:focus,
        .form-group textarea:focus {
            outline: none;
            border-color: #7fb3a3;
            box-shadow: 0 0 0 3px rgba(127, 179, 163, 0.1);
        }

        .form-group textarea {
            resize: vertical;
            min-height: 80px;
        }

        /* Checkbox Styles */
        .checkbox-container {
            display: flex;
            align-items: flex-start;
            margin: 25px 0;
            padding: 20px;
            background-color: #f8f9fa;
            border-radius: 8px;
            border: 1px solid #e9ecef;
        }

        .checkbox-container input[type="checkbox"] {
            width: auto;
            margin-right: 12px;
            margin-top: 2px;
            transform: scale(1.2);
            accent-color: #7fb3a3;
        }

        .checkbox-text {
            color: #555;
            font-size: 14px;
            line-height: 1.5;
        }

        /* Button Styles */
        .form-buttons {
            display: flex;
            gap: 15px;
            justify-content: center;
            margin-top: 30px;
        }

        .btn {
            padding: 12px 30px;
            border: none;
            border-radius: 8px;
            font-size: 14px;
            font-weight: 500;
            cursor: pointer;
            transition: all 0.3s ease;
            text-decoration: none;
            display: inline-block;
            text-align: center;
        }

        .btn-primary {
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
        }

        .btn-primary:hover {
            transform: translateY(-2px);
            box-shadow: 0 5px 15px rgba(127, 179, 163, 0.4);
        }

        .btn-secondary {
            background: #6c757d;
            color: white;
        }

        .btn-secondary:hover {
            background: #5a6268;
            transform: translateY(-2px);
        }

        /* Success Message */
        .success-message {
            background: linear-gradient(135deg, #d4edda 0%, #c3e6cb 100%);
            color: #155724;
            padding: 20px;
            border-radius: 8px;
            border: 1px solid #c3e6cb;
            margin-bottom: 25px;
            text-align: center;
            font-weight: 500;
            box-shadow: 0 2px 10px rgba(21, 87, 36, 0.1);
        }

        .success-message .icon {
            font-size: 24px;
            margin-bottom: 10px;
            display: block;
        }

        /* Mobile Toggle Button */
        .mobile-toggle {
            display: none;
            position: fixed;
            top: 20px;
            left: 20px;
            background: #7fb3a3;
            color: white;
            border: none;
            padding: 10px;
            border-radius: 5px;
            cursor: pointer;
            z-index: 1001;
            font-size: 18px;
        }

        /* Footer */
        .footer {
            background: linear-gradient(135deg, #7fb3a3 0%, #5a9288 100%);
            color: white;
            text-align: center;
            padding: 20px;
            font-size: 14px;
            margin-top: auto;
            flex-shrink: 0;
        }

        /* Responsive Design */
        @media (max-width: 768px) {
            .mobile-toggle {
                display: block;
            }

            .sidebar {
                transform: translateX(-100%);
            }

            .sidebar.active {
                transform: translateX(0);
            }

            .main-content {
                margin-left: 0;
                width: 100%;
                min-height: 100vh;
                display: flex;
                flex-direction: column;
            }

            .content-header {
                padding-left: 70px;
            }

            .form-container {
                margin: 0 15px 30px;
                padding: 25px;
            }

            .form-buttons {
                flex-direction: column;
            }

            .btn {
                width: 100%;
            }
        }
    </style>
</head>
<body>
    <!-- Mobile Toggle Button -->
    <button class="mobile-toggle" onclick="toggleSidebar()">☰</button>

    <!-- Sidebar -->
    <div class="sidebar" id="sidebar">
        <div class="sidebar-header">
            <img src="AVATAR.png" alt="Avatar">
            <h3><?php echo htmlspecialchars($_SESSION['lastname']); ?></h3>
        </div>
        <div class="sidebar-menu">
            <a href="my.php">My Board</a>
            <a href="leaveform.php" class="active">Apply Leave</a>
            <a href="feedback.php">Feedback</a>
            <a href="passchange.php">Manage Password</a>
            <a href="logout.php">Log Out</a>
        </div>
    </div>

    <!-- Main Content -->
    <div class="main-content">
        <div class="content-header">
            <h1>Apply for Leave</h1>
            <p>Submit your leave application for approval</p>
        </div>

        <div class="container">
            <div class="form-container">
                <h2 class="form-title">Leave Application Form</h2>
                
                <form method="POST" enctype="multipart/form-data">
                    <div class="form-group">
                        <label for="lastname">Last Name *</label>
                        <input type="text" id="lastname" name="lastname" placeholder="Enter your last name" required>
                    </div>

                    <div class="form-group">
                        <label for="email">Email Address *</label>
                        <input type="email" id="email" name="email" placeholder="Enter your email address" required>
                    </div>
                    
                    <div class="form-group">
                        <label for="leavetype">Type of Leave *</label>
                        <select id="leavetype" name="leavetype" required>
                            <option value="">-- Select Leave Type --</option>
                            <option value="Paid">Paid Leave</option>
                            <option value="Unpaid">Unpaid Leave</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="leavecatergory">Leave Category *</label>
                        <select id="leavecatergory" name="leavecatergory" required>
                            <option value="">-- Select Leave Category --</option>
                            <option value="Mandatory">Mandatory Leave</option>
                            <option value="Maternity">Maternity Leave</option>
                            <option value="Casual">Casual Leave</option>
                            <option value="Paternity">Paternity Leave</option>
                        </select>
                    </div>

                    <div class="form-group">
                        <label for="startdate">Start Date *</label>
                        <input type="date" id="startdate" name="startdate" required>
                    </div>

                    <div class="form-group">
                        <label for="enddate">End Date *</label>
                        <input type="date" id="enddate" name="enddate" required>
                    </div>

                    <div class="form-group">
                        <label for="fromwhere">From (Location) *</label>
                        <input type="text" id="fromwhere" name="fromwhere" placeholder="Current location/office" required>
                    </div>

                    <div class="form-group">
                        <label for="towhere">To (Destination) *</label>
                        <input type="text" id="towhere" name="towhere" placeholder="Destination location" required>
                    </div>

                    <div class="form-group">
                        <label for="description">Description/Reason</label>
                        <textarea id="description" name="description" placeholder="Please provide details about your leave request..."></textarea>
                    </div>

                    <div class="form-group">
                        <label for="file">Supporting Documents</label>
                        <input type="file" id="file" name="file" accept=".jpg,.jpeg,.png,.pdf,.doc,.docx,.ppt,.pptx">
                        <small style="color: #666; font-size: 12px; margin-top: 5px; display: block;">
                            Accepted formats: JPG, PNG, PDF, DOC, DOCX, PPT, PPTX (Max size: 5MB)
                        </small>
                    </div>

                    <div class="checkbox-container">
                        <input type="checkbox" id="terms" required>
                        <label for="terms" class="checkbox-text">
                            I hereby confirm that the information provided above is accurate and complete. I understand that any false information may result in the rejection of my leave application. I agree to abide by the company's leave policies and procedures.
                        </label>
                    </div>

                    <div class="form-buttons">
                        <button type="submit" class="btn btn-primary">Submit Application</button>
                        <a href="my.php" class="btn btn-secondary">Return to Dashboard</a>
                    </div>
                </form>

                <?php if (!empty($successMessage)): ?>
                    <div class="success-message">
                        <span class="icon">✅</span>
                        <?php echo htmlspecialchars($successMessage); ?>
                        <br><br>
                        <a href="my.php" class="btn btn-secondary">View My Applications</a>
                    </div>
                <?php endif; ?>
            </div>
        </div>

        <div class="footer">
            © 2025 Employee Leave Management System. All rights reserved.
        </div>
    </div>

    <script>
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Close sidebar when clicking outside on mobile
        document.addEventListener('click', function(event) {
            const sidebar = document.getElementById('sidebar');
            const toggle = document.querySelector('.mobile-toggle');
            
            if (window.innerWidth <= 768 && !sidebar.contains(event.target) && !toggle.contains(event.target)) {
                sidebar.classList.remove('active');
            }
        });

        // Date validation
        document.getElementById('startdate').addEventListener('change', function() {
            document.getElementById('enddate').min = this.value;
        });
    </script>
</body>
</html>